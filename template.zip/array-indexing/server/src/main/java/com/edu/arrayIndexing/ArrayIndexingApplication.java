package com.edu.arrayIndexing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArrayIndexingApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArrayIndexingApplication.class, args);
	}

}
